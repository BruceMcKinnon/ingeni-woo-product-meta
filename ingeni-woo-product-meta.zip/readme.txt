=== Ingeni Woo Product Meta ===

Contributors: Bruce McKinnon
Tags: woocommerce, seo
Requires at least: 4.8
Tested up to: 5.1.1
Stable tag: 2019.01

Used in conjunction with Woocommerce. Extends the standard Woocommerce product JSON-LD meta descrition.

== Description ==

* - Used in conjunction with Woocommerce. 

* - Automatically adds meta descriptions for the Brand and MPN (manf Part Number) to the standard Woo product JSON-LD on each product page.




== Installation ==

1. Upload the 'ingeni-woo-product-meta’ folder to the '/wp-content/plugins/' directory.

2. Activate the plugin through the 'Plugins' menu in WordPress.



== Frequently Asked Questions ==





== Changelog ==

v2019.01 - Initial version. Adds the ‘brand’ and ‘mpn’ fields.
